(function(){/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	__webpack_require__(27);

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var messaging = __webpack_require__(28);
	var injectScript = __webpack_require__(30);
	var canUseSovetnik = __webpack_require__(32);
	var postMessageParser = __webpack_require__(33);
	var postMessage = __webpack_require__(34);

	var sovetnikRE = /^https?:\/\/sovetnik/;
	var sovetnikInfo = undefined;

	function initListeners() {
	    messaging.sendMessage({
	        type: 'getSovetnikInfo'
	    }, function (info) {
	        sovetnikInfo = info;

	        if (sovetnikInfo) {
	            canUseSovetnik(document.URL, document.referrer, function () {
	                if (typeof startSovetnik !== 'undefined') {
	                    startSovetnik(sovetnikInfo.settings);
	                } else {
	                    injectScript(document, sovetnikInfo.url, sovetnikInfo.settings);
	                }
	            });
	        }
	    });

	    postMessage.on(onMessage);
	}

	var commandHandlers = {
	    getDomainData: function getDomainData(message, origin) {
	        messaging.sendMessage({
	            type: 'getDomainData',
	            domain: message.data.domain
	        }, function (domainData) {
	            message.response = domainData;
	            postMessage.trigger(JSON.stringify(message), origin);
	        });
	    },

	    getSovetnikInfo: function getSovetnikInfo(message, origin) {
	        message.response = sovetnikInfo.settings;
	        postMessage.trigger(JSON.stringify(message), origin);
	    },

	    serverMessage: function serverMessage(message) {
	        messaging.sendMessage({
	            type: message.data.type,
	            domain: message.data.domain || window.location.host
	        });
	    },

	    showSettingsPage: function showSettingsPage() {
	        messaging.sendMessage({
	            type: 'showSettingsPage'
	        });
	    },

	    showNotification: function showNotification(message) {
	        messaging.sendMessage({
	            type: 'showNotification',
	            notification: message.data
	        });
	    },

	    clearNotification: function clearNotification(message) {
	        messaging.sendMessage({
	            type: 'clearNotification',
	            action: message.data
	        });
	    },

	    sovetnikProductResponse: function sovetnikProductResponse(message) {
	        messaging.sendMessage({
	            type: 'sovetnikProductResponse',
	            response: message.data
	        });
	    }
	};

	function onMessage(event) {
	    var message = postMessageParser.getMessageFromEvent(event);

	    if (message && sovetnikInfo && sovetnikInfo.settings) {
	        if (sovetnikInfo.settings.clid) {
	            if (sovetnikInfo.settings.clid != message.clid) {
	                return;
	            }
	        } else if (sovetnikInfo.settings.affId != message.affId) {
	            return;
	        }

	        //message from our script
	        if (message.command) {
	            commandHandlers[message.command](message, event.origin);
	        }
	    }
	}

	if (window && window.document && (window.self === window.top || sovetnikRE.test(window.location.href))) {
	    if (window.opera) {
	        if (window.document.readyState === 'complete' || window.document.readyState === 'interactive') {
	            initListeners();
	        } else {
	            window.document.addEventListener('DOMContentLoaded', initListeners, false);
	        }
	    } else {
	        initListeners();
	    }
	}

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var messaging = undefined;

	// #if chrome,opera,firefox-webextension
	messaging = __webpack_require__(29);
	// #end

	module.exports = messaging;

/***/ },
/* 29 */
/***/ function(module, exports) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	"use strict";

	var messaging = {
	    sendMessage: function sendMessage(msg, responseCallback) {
	        responseCallback = responseCallback || function () {};

	        browser.runtime.sendMessage(msg, function () {
	            var args = arguments;
	            setTimeout(function () {
	                responseCallback.apply(this, args);
	            }, 0);
	        });

	        return this;
	    },

	    onMessage: function onMessage(listener) {
	        browser.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	            return listener(request, sendResponse);
	        });
	    }
	};

	module.exports = messaging;

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var injectScript = undefined;
	// #if chrome,opera,xul
	injectScript = __webpack_require__(31);
	// #end

	module.exports = injectScript;

/***/ },
/* 31 */
/***/ function(module, exports) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	function injectScript(doc, url, settings) {
	    var script = doc.createElement('script');
	    var params = [];

	    params.push('mbr=true');
	    params.push('settings=' + encodeURIComponent(JSON.stringify(settings)));
	    params = params.join('&');

	    url += '?' + params;

	    script.setAttribute('src', url);
	    script.setAttribute('type', 'text/javascript');
	    script.setAttribute('charset', 'UTF-8');

	    doc.body.appendChild(script);
	}

	module.exports = injectScript;

/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var messaging = __webpack_require__(28);

	function canUseSovetnik(url, referrer, successCallback) {
	    messaging.sendMessage({
	        type: 'canUseSovetnik',
	        url: url,
	        referrer: referrer
	    }, function (res) {
	        if (res) {
	            successCallback();
	        }
	    });
	}

	module.exports = canUseSovetnik;

/***/ },
/* 33 */
/***/ function(module, exports) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var postMessageParser = {
	    /**
	     * return message if postMessage event was sent from our script
	     * @param {Object} event
	     * @param {Object} event.data
	     * @return {?Object}
	     */
	    getMessageFromEvent: function getMessageFromEvent(event) {
	        if (!event.data) {
	            return null;
	        }

	        var message = event.data;

	        if (typeof message === 'string') {
	            try {
	                message = JSON.parse(message);
	            } catch (ex) {
	                return null;
	            }
	        }

	        var isOurMessage = message && message.type === 'MBR_ENVIRONMENT' && !message.hasOwnProperty('response') && (message.clid || message.affId);

	        if (isOurMessage) {
	            return message;
	        }

	        return null;
	    }
	};

	module.exports = postMessageParser;

/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * @callback postMessageCallback
	 * @param {Object} event
	 * @param {Object|String} event.data
	 */

	'use strict';

	var hub = __webpack_require__(35);

	/**
	 * добавляем обработчик 'message' события. Для наших расширений общение реализуется с помощью нашей функции
	 * которая определяется в контент-скрипте. 
	 * 
	 * @param {postMessageCallback} listener
	 * @param {Boolean} forceUseOriginalPostMessage=false - показывает, что не нужно использовать нашу собственную функцию.
	 *                      Полезно, если мы хотим общаться со страницей (например со страницей настроек или с лендингом)
	 */
	function addMessageListener(listener) {
	    var forceUseOriginalPostMessage = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];

	    if (window.svtPostMessage && !forceUseOriginalPostMessage) {
	        window.svtPostMessage.on(listener);
	    } else {
	        if (window.addEventListener) {
	            window.addEventListener('message', listener);
	        } else {
	            window.attachEvent('onmessage', listener);
	        }
	    }
	}

	var restoreOriginalPostMessageHandlerTimeoutId = undefined;
	var originalStopImmediatePropagation = MessageEvent.prototype.stopImmediatePropagation;

	function getMessageFromEvent(event) {
	    var message = event.data;

	    if (typeof message === 'string') {
	        try {
	            message = JSON.parse(message);
	        } catch (ex) {
	            message = null;
	        }
	    }

	    return message;
	}

	function isOurEvent(event) {
	    var message = getMessageFromEvent(event);

	    return message && message.type === 'MBR_ENVIRONMENT';
	}

	function needTrackImmediatePropagation(event) {
	    var message = getMessageFromEvent(event);

	    return message && message.command === 'getDomainData';
	}

	function instrumentPostMessageHandler() {
	    clearTimeout(restoreOriginalPostMessageHandlerTimeoutId);

	    MessageEvent.prototype.stopImmediatePropagation = function () {
	        if (isOurEvent(this)) {
	            if (needTrackImmediatePropagation(this)) {
	                hub.trigger('post-message-error', true);
	            }
	        } else {
	            originalStopImmediatePropagation.call(this);
	        }
	    };

	    restoreOriginalPostMessageHandlerTimeoutId = setTimeout(function () {
	        MessageEvent.prototype.stopImmediatePropagation = originalStopImmediatePropagation;
	    }, 1500);
	}

	/**
	 * У FF своя атмосфера.
	 * В наших расширениях мы используем свою собственную функцию для общения между контент-скриптами
	 * @param {Object|String} message
	 * @param {String} origin
	 * @param {Boolean} forceUseOriginalPostMessage=false - показывает, что не нужно использовать нашу собственную функцию. 
	 *                      Полезно, если мы хотим общаться со страницей (например со страницей настроек или с лендингом) 
	 */
	function triggerPostMessage(message, origin) {
	    var forceUseOriginalPostMessage = arguments.length <= 2 || arguments[2] === undefined ? false : arguments[2];

	    if (window.svtPostMessage && !forceUseOriginalPostMessage) {
	        window.svtPostMessage.trigger(message);
	    } else if (window.wrappedJSObject && window.wrappedJSObject.postMessage) {
	        window.wrappedJSObject.postMessage(message, origin);
	    } else {
	        instrumentPostMessageHandler();

	        window.postMessage(message, origin);
	    }
	}

	module.exports = {
	    on: addMessageListener,
	    trigger: triggerPostMessage
	};

/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * © 2017 ООО «Яндекс.Маркет» / © 2017 Yandex.Market LLC
	 */

	'use strict';

	var _require = __webpack_require__(36);

	var Mediator = _require.Mediator;

	var hub = undefined;

	module.exports = hub || new Mediator();

/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	/*jslint bitwise: true, nomen: true, plusplus: true, white: true */

	/*!
	* Mediator.js Library v0.9.7
	* https://github.com/ajacksified/Mediator.js
	*
	* Copyright 2013, Jack Lawson
	* MIT Licensed (http://www.opensource.org/licenses/mit-license.php)
	*
	* For more information: http://thejacklawson.com/2011/06/mediators-for-modularized-asynchronous-programming-in-javascript/index.html
	* Project on GitHub: https://github.com/ajacksified/Mediator.js
	*
	* Last update: October 19 2013
	*/

	(function(global, factory) {
	  'use strict';

	  if(true) {
	    // Node/CommonJS
	    exports.Mediator = factory();
	  } else if(typeof define === 'function' && define.amd) {
	    // AMD
	    define('mediator-js', [], function() {
	      global.Mediator = factory();
	      return global.Mediator;
	    });
	  } else {
	    // Browser global
	    global.Mediator = factory();
	  }
	}(this, function() {
	  'use strict';

	  // We'll generate guids for class instances for easy referencing later on.
	  // Subscriber instances will have an id that can be refernced for quick
	  // lookups.

	  function guidGenerator() {
	    var S4 = function() {
	       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
	    };

	    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
	  }

	  // Subscribers are instances of Mediator Channel registrations. We generate
	  // an object instance so that it can be updated later on without having to
	  // unregister and re-register. Subscribers are constructed with a function
	  // to be called, options object, and context.

	  function Subscriber(fn, options, context){
	    if(!(this instanceof Subscriber)) {
	      return new Subscriber(fn, options, context);
	    }

	    this.id = guidGenerator();
	    this.fn = fn;
	    this.options = options;
	    this.context = context;
	    this.channel = null;
	  }

	  Subscriber.prototype = {
	    // Mediator.update on a subscriber instance can update its function,context,
	    // or options object. It takes in an object and looks for fn, context, or
	    // options keys.

	    update: function(options){
	      if(options){
	        this.fn = options.fn || this.fn;
	        this.context = options.context || this.context;
	        this.options = options.options || this.options;
	        if(this.channel && this.options && this.options.priority !== undefined) {
	            this.channel.setPriority(this.id, this.options.priority);
	        }
	      }
	    }
	  };


	  function Channel(namespace, parent){
	    if(!(this instanceof Channel)) {
	      return new Channel(namespace);
	    }

	    this.namespace = namespace || "";
	    this._subscribers = [];
	    this._channels = [];
	    this._parent = parent;
	    this.stopped = false;
	  }

	  // A Mediator channel holds a list of sub-channels and subscribers to be fired
	  // when Mediator.publish is called on the Mediator instance. It also contains
	  // some methods to manipulate its lists of data; only setPriority and
	  // StopPropagation are meant to be used. The other methods should be accessed
	  // through the Mediator instance.

	  Channel.prototype = {
	    addSubscriber: function(fn, options, context){
	      var subscriber = new Subscriber(fn, options, context);

	      if(options && options.priority !== undefined){
	        // Cheap hack to either parse as an int or turn it into 0. Runs faster
	        // in many browsers than parseInt with the benefit that it won't
	        // return a NaN.
	        options.priority = options.priority >> 0;

	        if(options.priority < 0){ options.priority = 0; }
	        if(options.priority >= this._subscribers.length){ options.priority = this._subscribers.length-1; }

	        this._subscribers.splice(options.priority, 0, subscriber);
	      }else{
	        this._subscribers.push(subscriber);
	      }

	      subscriber.channel = this;

	      return subscriber;
	    },

	    // The channel instance is passed as an argument to the mediator subscriber,
	    // and further subscriber propagation can be called with
	    // channel.StopPropagation().
	    stopPropagation: function(){
	      this.stopped = true;
	    },

	    getSubscriber: function(identifier){
	      var x = 0,
	          y = this._subscribers.length;

	      for(x, y; x < y; x++){
	        if(this._subscribers[x].id === identifier || this._subscribers[x].fn === identifier){
	          return this._subscribers[x];
	        }
	      }
	    },

	    // Channel.setPriority is useful in updating the order in which Subscribers
	    // are called, and takes an identifier (subscriber id or named function) and
	    // an array index. It will not search recursively through subchannels.

	    setPriority: function(identifier, priority){
	      var oldIndex = 0,
	          x = 0,
	          sub, firstHalf, lastHalf, y;

	      for(x = 0, y = this._subscribers.length; x < y; x++){
	        if(this._subscribers[x].id === identifier || this._subscribers[x].fn === identifier){
	          break;
	        }
	        oldIndex ++;
	      }

	      sub = this._subscribers[oldIndex];
	      firstHalf = this._subscribers.slice(0, oldIndex);
	      lastHalf = this._subscribers.slice(oldIndex+1);

	      this._subscribers = firstHalf.concat(lastHalf);
	      this._subscribers.splice(priority, 0, sub);
	    },

	    addChannel: function(channel){
	      this._channels[channel] = new Channel((this.namespace ? this.namespace + ':' : '') + channel, this);
	    },

	    hasChannel: function(channel){
	      return this._channels.hasOwnProperty(channel);
	    },

	    returnChannel: function(channel){
	      return this._channels[channel];
	    },

	    removeSubscriber: function(identifier){
	      var x = this._subscribers.length - 1;

	      // If we don't pass in an id, we're clearing all
	      if(!identifier){
	        this._subscribers = [];
	        return;
	      }

	      // Going backwards makes splicing a whole lot easier.
	      for(x; x >= 0; x--) {
	        if(this._subscribers[x].fn === identifier || this._subscribers[x].id === identifier){
	          this._subscribers[x].channel = null;
	          this._subscribers.splice(x,1);
	        }
	      }
	    },

	    // This will publish arbitrary arguments to a subscriber and then to parent
	    // channels.

	    publish: function(data){
	      var x = 0,
	          y = this._subscribers.length,
	          called = false,
	          subscriber, l,
	          subsBefore,subsAfter;

	      // Priority is preserved in the _subscribers index.
	      for(x, y; x < y; x++) {
	        called = false;

	        if(!this.stopped){
	          subscriber = this._subscribers[x];
	          if(subscriber.options !== undefined && typeof subscriber.options.predicate === "function"){
	            if(subscriber.options.predicate.apply(subscriber.context, data)){
	              subscriber.fn.apply(subscriber.context, data);
	              called = true;
	            }
	          }else{
	            subsBefore = this._subscribers.length;
	            subscriber.fn.apply(subscriber.context, data);
	            subsAfter = this._subscribers.length;
	            y = subsAfter;
	            if (subsAfter === subsBefore - 1){
	              x--;
	            }
	            called = true;
	          }
	        }

	        if(called && subscriber.options && subscriber.options !== undefined){
	          subscriber.options.calls--;

	          if(subscriber.options.calls < 1){
	            this.removeSubscriber(subscriber.id);
	            y--;
	            x--;
	          }
	        }
	      }

	      if(this._parent){
	        this._parent.publish(data);
	      }

	      this.stopped = false;
	    }
	  };

	  function Mediator() {
	    if(!(this instanceof Mediator)) {
	      return new Mediator();
	    }

	    this._channels = new Channel('');
	  }

	  // A Mediator instance is the interface through which events are registered
	  // and removed from publish channels.

	  Mediator.prototype = {

	    // Returns a channel instance based on namespace, for example
	    // application:chat:message:received

	    getChannel: function(namespace){
	      var channel = this._channels,
	          namespaceHierarchy = namespace.split(':'),
	          x = 0, 
	          y = namespaceHierarchy.length;

	      if(namespace === ''){
	        return channel;
	      }

	      if(namespaceHierarchy.length > 0){
	        for(x, y; x < y; x++){

	          if(!channel.hasChannel(namespaceHierarchy[x])){
	            channel.addChannel(namespaceHierarchy[x]);
	          }

	          channel = channel.returnChannel(namespaceHierarchy[x]);
	        }
	      }

	      return channel;
	    },

	    // Pass in a channel namespace, function to be called, options, and context
	    // to call the function in to Subscribe. It will create a channel if one
	    // does not exist. Options can include a predicate to determine if it
	    // should be called (based on the data published to it) and a priority
	    // index.

	    subscribe: function(channelName, fn, options, context){
	      var channel = this.getChannel(channelName);

	      options = options || {};
	      context = context || {};

	      return channel.addSubscriber(fn, options, context);
	    },

	    // Pass in a channel namespace, function to be called, options, and context
	    // to call the function in to Subscribe. It will create a channel if one
	    // does not exist. Options can include a predicate to determine if it
	    // should be called (based on the data published to it) and a priority
	    // index.

	    once: function(channelName, fn, options, context){
	      options = options || {};
	      options.calls = 1;

	      return this.subscribe(channelName, fn, options, context);
	    },

	    // Returns a subscriber for a given subscriber id / named function and
	    // channel namespace

	    getSubscriber: function(identifier, channel){
	      return this.getChannel(channel || "").getSubscriber(identifier);
	    },

	    // Remove a subscriber from a given channel namespace recursively based on
	    // a passed-in subscriber id or named function.

	    remove: function(channelName, identifier){
	      this.getChannel(channelName).removeSubscriber(identifier);
	    },

	    // Publishes arbitrary data to a given channel namespace. Channels are
	    // called recursively downwards; a post to application:chat will post to
	    // application:chat:receive and application:chat:derp:test:beta:bananas.
	    // Called using Mediator.publish("application:chat", [ args ]);

	    publish: function(channelName){
	      var args = Array.prototype.slice.call(arguments, 1),
	          channel = this.getChannel(channelName);

	      args.push(channel);

	      this.getChannel(channelName).publish(args);
	    }
	  };

	  // Alias some common names for easy interop
	  Mediator.prototype.on = Mediator.prototype.subscribe;
	  Mediator.prototype.bind = Mediator.prototype.subscribe;
	  Mediator.prototype.emit = Mediator.prototype.publish;
	  Mediator.prototype.trigger = Mediator.prototype.publish;
	  Mediator.prototype.off = Mediator.prototype.remove;

	  // Finally, expose it all.

	  Mediator.Channel = Channel;
	  Mediator.Subscriber = Subscriber;
	  Mediator.version = "0.9.7";

	  return Mediator;
	}));
	  


/***/ }
/******/ ]);})();